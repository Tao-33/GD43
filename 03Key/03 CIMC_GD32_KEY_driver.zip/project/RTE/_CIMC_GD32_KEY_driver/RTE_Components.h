
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'CIMC_GD32_KEY_driver' 
 * Target:  'CIMC_GD32_KEY_driver' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "gd32f4xx.h"


#endif /* RTE_COMPONENTS_H */
