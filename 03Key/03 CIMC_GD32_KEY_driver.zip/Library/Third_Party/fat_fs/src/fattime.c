

#include "integer.h"
#include "fattime.h"
//#include "rtc.h" //RPi

DWORD get_fattime (void)
{
  return 0;
}

